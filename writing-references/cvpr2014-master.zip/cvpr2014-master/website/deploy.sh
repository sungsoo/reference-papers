scp index.html preview_small.png teaser.jpg di.ens.fr:/users/thetis/willow/www/research/fastvideofeat
