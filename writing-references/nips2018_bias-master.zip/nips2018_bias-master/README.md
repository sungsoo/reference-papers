# nips2018_bias
This is a competition proposal for NIPS 2018 on ethnic and gender bias on facial attributes recognition
