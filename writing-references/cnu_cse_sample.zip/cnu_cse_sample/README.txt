
This style file is for editing your Ph.D or Ms thesis on LaTeX.
This style file is tested using texlive-2010 distribution on Mac OS X,
and the sample source file is tested by pdflatex 
to see if the phd.tex file is successfully created.

Please leave your questions and comment at bjlee@etri.re.kr 
or guestboard at http://www.buggymind.com/ 

Best regards,
Byungjoon Lee


